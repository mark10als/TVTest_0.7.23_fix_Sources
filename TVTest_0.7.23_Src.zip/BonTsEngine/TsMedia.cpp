// TsMedia.cpp: TS���f�B�A���b�p�[�N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TsMedia.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


/////////////////////////////////////////////////////////////////////////////
// CPesPacket�N���X�̍\�z/����
/////////////////////////////////////////////////////////////////////////////

CPesPacket::CPesPacket()
	: CMediaData()
{
	Reset();
}

CPesPacket::CPesPacket(const DWORD dwBuffSize)
	: CMediaData(dwBuffSize)
{
	Reset();
}

CPesPacket::CPesPacket(const CPesPacket &Operand)
	: CMediaData()
{
	Reset();

	*this = Operand;
}

CPesPacket & CPesPacket::operator = (const CPesPacket &Operand)
{
	if (&Operand != this) {
		// �C���X�^���X�̃R�s�[
		CMediaData::operator = (Operand);
		m_Header = Operand.m_Header;
	}

	return *this;
}

const bool CPesPacket::ParseHeader(void)
{
	if(m_dwDataSize < 9UL)return false;														// PES_header_data_length�܂ł�6�o�C�g
	else if(m_pData[0] != 0x00U || m_pData[1] != 0x00U || m_pData[2] != 0x01U)return false;	// packet_start_code_prefix�ُ�
	else if((m_pData[6] & 0xC0U) != 0x80U)return false;										// �Œ�r�b�g�ُ�

	// �w�b�_���
	m_Header.byStreamID					= m_pData[3];										// +3 bit7-0
	m_Header.wPacketLength				= ((WORD)m_pData[4] << 8) | (WORD)m_pData[5];		// +4, +5
	m_Header.byScramblingCtrl			= (m_pData[6] & 0x30U) >> 4;						// +6 bit5-4
	m_Header.bPriority					= (m_pData[6] & 0x08U)? true : false;				// +6 bit3
	m_Header.bDataAlignmentIndicator	= (m_pData[6] & 0x04U)? true : false;				// +6 bit2
	m_Header.bCopyright					= (m_pData[6] & 0x02U)? true : false;				// +6 bit1
	m_Header.bOriginalOrCopy			= (m_pData[6] & 0x01U)? true : false;				// +6 bit0
	m_Header.byPtsDtsFlags				= (m_pData[7] & 0xC0U) >> 6;						// +7 bit7-6
	m_Header.bEscrFlag					= (m_pData[7] & 0x20U)? true : false;				// +7 bit5
	m_Header.bEsRateFlag				= (m_pData[7] & 0x10U)? true : false;				// +7 bit4
	m_Header.bDsmTrickModeFlag			= (m_pData[7] & 0x08U)? true : false;				// +7 bit3
	m_Header.bAdditionalCopyInfoFlag	= (m_pData[7] & 0x04U)? true : false;				// +7 bit2
	m_Header.bCrcFlag					= (m_pData[7] & 0x02U)? true : false;				// +7 bit1
	m_Header.bExtensionFlag				= (m_pData[7] & 0x01U)? true : false;				// +7 bit0
	m_Header.byHeaderDataLength			= m_pData[8];										// +8 bit7-0

	// �w�b�_�̃t�H�[�}�b�g�K�������`�F�b�N����
	if(m_Header.byScramblingCtrl != 0U)return false;	// Not scrambled �̂ݑΉ�
	else if(m_Header.byPtsDtsFlags == 1U)return false;	// ����`�̃t���O

	return true;
}

void CPesPacket::Reset(void)
{
	// �f�[�^���N���A����
	ClearSize();
	::ZeroMemory(&m_Header, sizeof(m_Header));
}

const BYTE CPesPacket::GetStreamID(void) const
{
	// Stream ID��Ԃ�
	return m_Header.byStreamID;
}

const WORD CPesPacket::GetPacketLength(void) const
{
	// PES Packet Length��Ԃ�
	return m_Header.wPacketLength;
}

const BYTE CPesPacket::GetScramblingCtrl(void) const
{	// PES Scrambling Control��Ԃ�
	return m_Header.byScramblingCtrl;
}

const bool CPesPacket::IsPriority(void) const
{	// PES Priority��Ԃ�
	return m_Header.bPriority;
}

const bool CPesPacket::IsDataAlignmentIndicator(void) const
{
	// Data Alignment Indicator��Ԃ�
	return m_Header.bDataAlignmentIndicator;
}

const bool CPesPacket::IsCopyright(void) const
{
	// Copyright��Ԃ�
	return m_Header.bCopyright;
}

const bool CPesPacket::IsOriginalOrCopy(void) const
{
	// Original or Copy��Ԃ�
	return m_Header.bOriginalOrCopy;
}

const BYTE CPesPacket::GetPtsDtsFlags(void) const
{
	// PTS DTS Flags��Ԃ�
	return m_Header.byPtsDtsFlags;
}

const bool CPesPacket::IsEscrFlag(void) const
{
	// ESCR Flag��Ԃ�
	return m_Header.bEscrFlag;
}

const bool CPesPacket::IsEsRateFlag(void) const
{
	// ES Rate Flag��Ԃ�
	return m_Header.bEsRateFlag;
}

const bool CPesPacket::IsDsmTrickModeFlag(void) const
{
	// DSM Trick Mode Flag��Ԃ�
	return m_Header.bDsmTrickModeFlag;
}

const bool CPesPacket::IsAdditionalCopyInfoFlag(void) const
{
	// Additional Copy Info Flag��Ԃ�
	return m_Header.bAdditionalCopyInfoFlag;
}

const bool CPesPacket::IsCrcFlag(void) const
{
	// PES CRC Flag��Ԃ�
	return m_Header.bCrcFlag;
}

const bool CPesPacket::IsExtensionFlag(void) const
{
	// PES Extension Flag��Ԃ�
	return m_Header.bExtensionFlag;
}

const BYTE CPesPacket::GetHeaderDataLength(void) const
{
	// PES Header Data Length��Ԃ�
	return m_Header.byHeaderDataLength;
}

const LONGLONG CPesPacket::GetPtsCount(void)const
{
	// PTS(Presentation Time Stamp)��Ԃ�
	if (m_Header.byPtsDtsFlags) {
		return HexToTimeStamp(&m_pData[9]);
	}

	// �G���[(PTS���Ȃ�)
	return -1LL;
}

const WORD CPesPacket::GetPacketCrc(void) const
{
	// PES Packet CRC��Ԃ�
	DWORD dwCrcPos = 9UL;

	// �ʒu���v�Z
	if(m_Header.byPtsDtsFlags == 2U)dwCrcPos += 5UL;
	if(m_Header.byPtsDtsFlags == 3U)dwCrcPos += 10UL;
	if(m_Header.bEscrFlag)dwCrcPos += 6UL;
	if(m_Header.bEsRateFlag)dwCrcPos += 3UL;
	if(m_Header.bDsmTrickModeFlag)dwCrcPos += 1UL;
	if(m_Header.bAdditionalCopyInfoFlag)dwCrcPos += 1UL;

	if(m_dwDataSize < (dwCrcPos + 2UL))return 0x0000U;

	return ((WORD)m_pData[dwCrcPos] << 8) | (WORD)m_pData[dwCrcPos + 1];
}

BYTE * CPesPacket::GetPayloadData(void) const
{
	// �y�C���[�h�|�C���^��Ԃ�
	const DWORD dwPayloadPos = m_Header.byHeaderDataLength + 9UL;

	return (m_dwDataSize >= (dwPayloadPos + 1UL))? &m_pData[dwPayloadPos] : NULL;
}

const DWORD CPesPacket::GetPayloadSize(void) const
{
	// �y�C���[�h�T�C�Y��Ԃ�(���ۂ̕ێ����Ă�@���p�P�b�g����菭�Ȃ��Ȃ邱�Ƃ�����)
	const DWORD dwHeaderSize = m_Header.byHeaderDataLength + 9UL;

	return (m_dwDataSize > dwHeaderSize)? (m_dwDataSize - dwHeaderSize) : 0UL;
}

inline const LONGLONG CPesPacket::HexToTimeStamp(const BYTE *pHexData)
{
	// 33bit 90KHz �^�C���X�^���v����͂���
	LONGLONG llCurPtsCount = 0LL;
	llCurPtsCount |= (LONGLONG)(pHexData[0] & 0x0EU) << 29;
	llCurPtsCount |= (LONGLONG)pHexData[1] << 22;
	llCurPtsCount |= (LONGLONG)(pHexData[2] & 0xFEU) << 14;
	llCurPtsCount |= (LONGLONG)pHexData[3] << 7;
	llCurPtsCount |= (LONGLONG)pHexData[4] >> 1;

	return llCurPtsCount;
}


//////////////////////////////////////////////////////////////////////
// CPesParser�N���X�̍\�z/����
//////////////////////////////////////////////////////////////////////

CPesParser::CPesParser(IPacketHandler *pPacketHandler)
	: m_pPacketHandler(pPacketHandler)
	, m_PesPacket(0x10005UL)
	, m_bIsStoring(false)
	, m_wStoreCrc(0x0000U)
	, m_dwStoreSize(0UL)
{

}

CPesParser::CPesParser(const CPesParser &Operand)
{
	*this = Operand;
}

CPesParser & CPesParser::operator = (const CPesParser &Operand)
{
	if (&Operand != this) {
		// �C���X�^���X�̃R�s�[
		m_pPacketHandler = Operand.m_pPacketHandler;
		m_PesPacket = Operand.m_PesPacket;
		m_bIsStoring = Operand.m_bIsStoring;
		m_wStoreCrc = Operand.m_wStoreCrc;
	}

	return *this;
}

const bool CPesParser::StorePacket(const CTsPacket *pPacket)
{
	const BYTE *pData = pPacket->GetPayloadData();
	const BYTE bySize = pPacket->GetPayloadSize();
	if(!bySize || !pData)return false;

	bool bTrigger = false;
	BYTE byPos = 0U;

	if(pPacket->m_Header.bPayloadUnitStartIndicator){
		// �w�b�_�擪 + [�y�C���[�h�f��]

		// PES�p�P�b�g���E�Ȃ��̃X�g�A����������
		if(m_bIsStoring && !m_PesPacket.GetPacketLength()){
			OnPesPacket(&m_PesPacket);
			}

		m_bIsStoring = false;
		bTrigger = true;
		m_PesPacket.ClearSize();

		byPos += StoreHeader(&pData[byPos], bySize - byPos);
		byPos += StorePayload(&pData[byPos], bySize - byPos);
		}
	else{
		// [�w�b�_�f��] + �y�C���[�h + [�X�^�b�t�B���O�o�C�g]
		byPos += StoreHeader(&pData[byPos], bySize - byPos);
		byPos += StorePayload(&pData[byPos], bySize - byPos);
		}

	return bTrigger;
}

void CPesParser::Reset(void)
{
	// ��Ԃ�����������
	m_PesPacket.Reset();
	m_bIsStoring = false;
	m_dwStoreSize = 0UL;
}

void CPesParser::OnPesPacket(const CPesPacket *pPacket) const
{
	// �n���h���Ăяo��
	if(m_pPacketHandler)m_pPacketHandler->OnPesPacket(this, pPacket);
}

const BYTE CPesParser::StoreHeader(const BYTE *pPayload, const BYTE byRemain)
{
	// �w�b�_����͂��ăZ�N�V�����̃X�g�A���J�n����
	if(m_bIsStoring)return 0U;

	const BYTE byHeaderRemain = 9U - (BYTE)m_PesPacket.GetSize();

	if(byRemain >= byHeaderRemain){
		// �w�b�_�X�g�A�����A�w�b�_����͂��ăy�C���[�h�̃X�g�A���J�n����
		m_PesPacket.AddData(pPayload, byHeaderRemain);
		if(m_PesPacket.ParseHeader()){
			// �w�b�_�t�H�[�}�b�gOK
			m_dwStoreSize = m_PesPacket.GetPacketLength();
			if(m_dwStoreSize)m_dwStoreSize += 6UL;
			m_bIsStoring = true;
			return byHeaderRemain;
			}
		else{
			// �w�b�_�G���[
			m_PesPacket.Reset();
			return byRemain;
			}
		}
	else{
		// �w�b�_�X�g�A�������A���̃f�[�^��҂�
		m_PesPacket.AddData(pPayload, byRemain);
		return byRemain;
		}
}

const BYTE CPesParser::StorePayload(const BYTE *pPayload, const BYTE byRemain)
{
	// �Z�N�V�����̃X�g�A����������
	if(!m_bIsStoring)return 0U;
	
	const DWORD dwStoreRemain = m_dwStoreSize - m_PesPacket.GetSize();

	if(m_dwStoreSize && (dwStoreRemain <= (DWORD)byRemain)){
		// �X�g�A����
		m_PesPacket.AddData(pPayload, dwStoreRemain);

		// CRC����A�R�[���o�b�N�ɃZ�N�V������n��
		OnPesPacket(&m_PesPacket);

		// ��Ԃ����������A���̃Z�N�V������M�ɔ�����
		m_PesPacket.Reset();
		m_bIsStoring = false;

		return (BYTE)dwStoreRemain;
		}
	else{
		// �X�g�A�������A���̃y�C���[�h��҂�
		m_PesPacket.AddData(pPayload, byRemain);
		return byRemain;
		}
}


//////////////////////////////////////////////////////////////////////
// CAdtsFrame�N���X�̍\�z/����
//////////////////////////////////////////////////////////////////////

CAdtsFrame::CAdtsFrame()
	: CMediaData()
{
	Reset();
}

CAdtsFrame::CAdtsFrame(const CAdtsFrame &Operand)
{
	Reset();

	*this = Operand;
}

CAdtsFrame & CAdtsFrame::operator = (const CAdtsFrame &Operand)
{
	if (&Operand != this) {
		// �C���X�^���X�̃R�s�[
		CMediaData::operator = (Operand);
		m_Header = Operand.m_Header;
	}

	return *this;
}

const bool CAdtsFrame::ParseHeader(void)
{
	// adts_fixed_header()
	if(m_dwDataSize < 7UL)return false;									// ADTS�w�b�_��7�o�C�g
	else if(m_pData[0] != 0xFFU || m_pData[1] != 0xF8U)return false;	// Syncword�AID�Alayer�Aprotection_absent�ُ�@��CRC�Ȃ��͔�Ή�
	
	m_Header.byProfile				= (m_pData[2] & 0xC0U) >> 6;									// +2 bit7-6
	m_Header.bySamplingFreqIndex	= (m_pData[2] & 0x3CU) >> 2;									// +2 bit5-2
	m_Header.bPrivateBit			= (m_pData[2] & 0x02U)? true : false;							// +2 bit1
	m_Header.byChannelConfig		= ((m_pData[2] & 0x01U) << 2) | ((m_pData[3] & 0xC0U) >> 6);	// +3 bit0, +4 bit7-6
	m_Header.bOriginalCopy			= (m_pData[3] & 0x20U)? true : false;							// +3 bit5
	m_Header.bHome					= (m_pData[3] & 0x10U)? true : false;							// +3 bit4

	// adts_variable_header()
	m_Header.bCopyrightIdBit		= (m_pData[3] & 0x08U)? true : false;							// +3 bit3
	m_Header.bCopyrightIdStart		= (m_pData[3] & 0x04U)? true : false;							// +3 bit2
	m_Header.wFrameLength			= ((WORD)(m_pData[3] & 0x03U) << 11) | ((WORD)m_pData[4] << 3) | ((WORD)(m_pData[5] & 0xE0U) >> 5);
	m_Header.wBufferFullness		= ((WORD)(m_pData[5] & 0x1FU) << 6) | ((WORD)(m_pData[6] & 0xFCU) >> 2);
	m_Header.byRawDataBlockNum		= m_pData[6] & 0x03U;

	// �t�H�[�}�b�g�K�����`�F�b�N
	if(m_Header.byProfile == 3U)
		return false;		// ����`�̃v���t�@�C��
	else if(m_Header.bySamplingFreqIndex > 0x0BU)
		return false;		// ����`�̃T���v�����O���g��
	else if(m_Header.byChannelConfig >= 3 && m_Header.byChannelConfig != 6)
		return false;		// �`�����l�����ُ�
	else if(m_Header.wFrameLength < 2U || m_Header.wFrameLength > 0x2000 - 7)
		return false;		// �f�[�^�Ȃ��̏ꍇ���Œ�CRC�̃T�C�Y���K�v
	else if(m_Header.byRawDataBlockNum)
		return false;		// �{�N���X�͒P���Raw Data Block�ɂ����Ή����Ȃ�

	return true;
}

void CAdtsFrame::Reset(void)
{
	// �f�[�^���N���A����
	ClearSize();	
	::ZeroMemory(&m_Header, sizeof(m_Header));
}

const BYTE CAdtsFrame::GetProfile(void) const
{
	// Profile ��Ԃ�
	return m_Header.byProfile;
}

const BYTE CAdtsFrame::GetSamplingFreqIndex(void) const
{
	// Sampling Frequency Index ��Ԃ�
	return m_Header.bySamplingFreqIndex;
}

const DWORD CAdtsFrame::GetSamplingFreq(void) const
{
	static const DWORD FreqTable[] = {
		96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000
	};
	return FreqTable[m_Header.bySamplingFreqIndex];
}

const bool CAdtsFrame::IsPrivateBit(void) const
{
	// Private Bit ��Ԃ�
	return m_Header.bPrivateBit;
}

const BYTE CAdtsFrame::GetChannelConfig(void) const
{
	// Channel Configuration ��Ԃ�
	return m_Header.byChannelConfig;
}

const bool CAdtsFrame::IsOriginalCopy(void) const
{
	// Original/Copy ��Ԃ�
	return m_Header.bOriginalCopy;
}

const bool CAdtsFrame::IsHome(void) const
{
	// Home ��Ԃ�
	return m_Header.bHome;
}

const bool CAdtsFrame::IsCopyrightIdBit(void) const
{
	// Copyright Identification Bit ��Ԃ�
	return m_Header.bCopyrightIdBit;
}

const bool CAdtsFrame::IsCopyrightIdStart(void) const
{
	// Copyright Identification Start ��Ԃ�
	return m_Header.bCopyrightIdStart;
}

const WORD CAdtsFrame::GetFrameLength(void) const
{
	// Frame Length ��Ԃ�
	return m_Header.wFrameLength;
}

const WORD CAdtsFrame::GetBufferFullness(void) const
{
	// ADTS Buffer Fullness ��Ԃ�
	return m_Header.wBufferFullness;
}

const BYTE CAdtsFrame::GetRawDataBlockNum(void) const
{
	// Number of Raw Data Blocks in Frame ��Ԃ�
	return m_Header.byRawDataBlockNum;
}


//////////////////////////////////////////////////////////////////////
// CAdtsParser�N���X�̍\�z/����
//////////////////////////////////////////////////////////////////////

CAdtsParser::CAdtsParser(IFrameHandler *pFrameHandler)
	: m_pFrameHandler(pFrameHandler)
{
	// ADTS�t���[���ő咷�̃o�b�t�@�m��
	m_AdtsFrame.GetBuffer(0x2000UL);

	Reset();
}

CAdtsParser::CAdtsParser(const CAdtsParser &Operand)
{
	*this = Operand;
}

CAdtsParser & CAdtsParser::operator = (const CAdtsParser &Operand)
{
	if (&Operand != this) {
		// �C���X�^���X�̃R�s�[
		m_pFrameHandler = Operand.m_pFrameHandler;
		m_AdtsFrame = Operand.m_AdtsFrame;
		m_bIsStoring = Operand.m_bIsStoring;
		m_wStoreCrc = Operand.m_wStoreCrc;
	}

	return *this;
}

const bool CAdtsParser::StorePacket(const CPesPacket *pPacket)
{
	return StoreEs(pPacket->GetPayloadData(), pPacket->GetPayloadSize());
}

const bool CAdtsParser::StoreEs(const BYTE *pData, const DWORD dwSize)
{
	if (pData == NULL || dwSize == 0)
		return false;

	bool bTrigger = false;
	DWORD dwPos = 0UL;

	do {
		if (!m_bIsStoring) {
			// �w�b�_����������
			m_bIsStoring = SyncFrame(pData[dwPos++]);
			if(m_bIsStoring)bTrigger = true;
		} else {
			// �f�[�^���X�g�A����
			const DWORD dwStoreRemain = m_AdtsFrame.GetFrameLength() - (WORD)m_AdtsFrame.GetSize();
			const DWORD dwDataRemain = dwSize - dwPos;

			if (dwStoreRemain <= dwDataRemain) {
				// �X�g�A����
				m_AdtsFrame.AddData(&pData[dwPos], dwStoreRemain);
				dwPos += dwStoreRemain;
				m_bIsStoring = false;

				// �{���Ȃ炱����CRC�`�F�b�N�����ׂ�
				// �`�F�b�N�Ώۗ̈悪�ςŕ��G�Ȃ̂ŕۗ��A�N���������܂���...

				// �t���[���o��
				OnAdtsFrame(&m_AdtsFrame);

				// ���̃t���[�����������邽�߃��Z�b�g
				m_AdtsFrame.ClearSize();
			} else {
				// �X�g�A�������A���̃y�C���[�h��҂�
				m_AdtsFrame.AddData(&pData[dwPos], dwDataRemain);
				break;
			}
		}
	} while (dwPos < dwSize);

	return bTrigger;
}

void CAdtsParser::Reset(void)
{
	// ��Ԃ�����������
	m_bIsStoring = false;
	m_AdtsFrame.Reset();
}

void CAdtsParser::OnPesPacket(const CPesParser *pPesParser, const CPesPacket *pPacket)
{
	// CPesParser::IPacketHandler�C���^�t�F�[�X�̎���
	StorePacket(pPacket);
}

void CAdtsParser::OnAdtsFrame(const CAdtsFrame *pFrame) const
{
	// �n���h���Ăяo��
	if(m_pFrameHandler)m_pFrameHandler->OnAdtsFrame(this, pFrame);
}

inline const bool CAdtsParser::SyncFrame(const BYTE byData)
{
	switch (m_AdtsFrame.GetSize()) {
	case 0UL :
		// syncword(8bit)
		if (byData == 0xFFU)
			m_AdtsFrame.AddByte(byData);
		break;

	case 1UL :
		// syncword(4bit), ID, layer, protection_absent	��CRC�t���̃t���[���̂ݑΉ�
		if (byData == 0xF8U)
			m_AdtsFrame.AddByte(byData);
		else
			m_AdtsFrame.ClearSize();
		break;

	case 2UL :
	case 3UL :
	case 4UL :
	case 5UL :
		// adts_fixed_header() - adts_variable_header()
		m_AdtsFrame.AddByte(byData);
		break;

	case 6UL :
		// �w�b�_���S�Ă������
		m_AdtsFrame.AddByte(byData);

		// �w�b�_����͂���
		if (m_AdtsFrame.ParseHeader())
			return true;
		m_AdtsFrame.ClearSize();
		break;

	default:
		// ��O
		m_AdtsFrame.ClearSize();
		break;
	}

	return false;
}


//////////////////////////////////////////////////////////////////////
// CMpeg2Sequence�N���X�̍\�z/����
//////////////////////////////////////////////////////////////////////

CMpeg2Sequence::CMpeg2Sequence()
	: CMediaData()
	, m_bFixSquareDisplay(false)
{
	Reset();
}

CMpeg2Sequence::CMpeg2Sequence(const CMpeg2Sequence &Operand)
{
	Reset();

	*this = Operand;
}

CMpeg2Sequence & CMpeg2Sequence::operator = (const CMpeg2Sequence &Operand)
{
	if (&Operand != this) {
		// �C���X�^���X�̃R�s�[
		CMediaData::operator = (Operand);
		m_Header = Operand.m_Header;
		m_bFixSquareDisplay = Operand.m_bFixSquareDisplay;
	}

	return *this;
}

const bool CMpeg2Sequence::ParseHeader(void)
{
	// �����ł�Start Code Prifix��Start Code�����`�F�b�N���Ȃ��B(�V�[�P���X�̓����݂̂�ړI�Ƃ���)

	// next_start_code()
	DWORD dwHeaderSize = 12UL;
	if(m_dwDataSize < dwHeaderSize)return false;
	else if(m_pData[0] || m_pData[1] || m_pData[2] != 0x01U || m_pData[3] != 0xB3U)return false;					// +0,+1,+2,+3	

	ZeroMemory(&m_Header,sizeof(m_Header));
	m_Header.wHorizontalSize			= ((WORD)m_pData[4] << 4) | ((WORD)(m_pData[5] & 0xF0U) >> 4);				// +4,+5 bit7-4
	m_Header.wVerticalSize				= ((WORD)(m_pData[5] & 0x0FU) << 8) | (WORD)m_pData[6];						// +5 bit3-0, +6
	m_Header.byAspectRatioInfo			= (m_pData[7] & 0xF0U) >> 4;												// +7 bit7-4
	BYTE * const pAspectRatioInfo = &m_pData[7];
	m_Header.byFrameRateCode			= m_pData[7] & 0x0FU;														// +7 bit3-0
	m_Header.dwBitRate					= ((DWORD)m_pData[8] << 10) | ((DWORD)m_pData[9] << 2) | ((DWORD)(m_pData[10] & 0xC0U) >> 6);	// +8, +9, +10 bit7-6
	m_Header.bMarkerBit					= (m_pData[10] & 0x20U)? true : false;										// +10 bit5
	m_Header.dwVbvBufferSize				= ((WORD)(m_pData[10] & 0x1FU) << 5) | ((WORD)(m_pData[11] & 0xF8U) >> 3);	// +10 bit4-0, +11 bit7-3
	m_Header.bConstrainedParamFlag		= (m_pData[11] & 0x04U)? true : false;										// +11 bit2
	m_Header.bLoadIntraQuantiserMatrix	= (m_pData[11] & 0x02U)? true : false;										// +11 bit1
	m_Header.bLoadNonIntraQuantiserMatrix=(m_pData[11] & 0x01U)? true : false;										// +11 bit0
	if (m_Header.bLoadIntraQuantiserMatrix) {
		dwHeaderSize += 64;
		if (m_dwDataSize < dwHeaderSize)
			return false;
	}
	if (m_Header.bLoadNonIntraQuantiserMatrix) {
		dwHeaderSize += 64;
		if (m_dwDataSize < dwHeaderSize)
			return false;
	}

	// �t�H�[�}�b�g�K�����`�F�b�N
	if (m_Header.wHorizontalSize == 0 || m_Header.wVerticalSize == 0)
		return false;
	if(!m_Header.byAspectRatioInfo || m_Header.byAspectRatioInfo > 4U)return false;		// �A�X�y�N�g�䂪�ُ�
	else if(!m_Header.byFrameRateCode || m_Header.byFrameRateCode > 8U)return false;	// �t���[�����[�g���ُ�
	else if(!m_Header.bMarkerBit)return false;											// �}�[�J�[�r�b�g���ُ�
	else if(m_Header.bConstrainedParamFlag)return false;								// Constrained Parameters Flag ���ُ�

	// �g���w�b�_��������
	DWORD SyncState = 0xFFFFFFFF;
	for (DWORD i = dwHeaderSize; i < min(m_dwDataSize - 1, 1024UL);) {
		SyncState = (SyncState << 8) | m_pData[i++];
		if (SyncState == 0x000001B5UL) {
			// �g���w�b�_����
			switch (m_pData[i] >> 4) {
			case 1:
				// �V�[�P���X�g��(48bits)
				if (i + 6 > m_dwDataSize)
					break;
				m_Header.Extention.Sequence.byProfileAndLevel = (m_pData[i + 0] & 0x0FU) << 4 | (m_pData[i + 1] >> 4);
				m_Header.Extention.Sequence.bProgressive = (m_pData[i + 1] & 0x08) != 0;
				m_Header.Extention.Sequence.byChromaFormat = (m_pData[i + 1] & 0x06U) >> 1;
				m_Header.wHorizontalSize |= (((m_pData[i + 1] & 0x01U) << 1) | ((m_pData[i + 2] & 0x80U) >> 7)) << 12;	// horizontal size extension
				m_Header.wVerticalSize   |= ((m_pData[i + 2] & 0x60U) >> 5) << 12;	// vertical size extension
				m_Header.dwBitRate |= (((DWORD)m_pData[i + 2] & 0x1FU) << 7) | (m_pData[i + 3] >> 1) << 18;	// bit rate extension
				if ((m_pData[i + 3] & 0x01U) == 0)	// marker bit
					break;
				m_Header.dwVbvBufferSize |= m_pData[i + 4] << 10;	// vbv buffer size extension
				m_Header.Extention.Sequence.bLowDelay = (m_pData[i + 5] & 0x80) != 0;
				m_Header.Extention.Sequence.byFrameRateExtN = (m_pData[i + 5] & 0x60U) >> 5;
				m_Header.Extention.Sequence.byFrameRateExtD = (m_pData[i + 5] & 0x18U) >> 3;
				m_Header.Extention.Sequence.bHave = true;
				i += 6;
				break;

			case 2:
				// �f�B�X�v���C�g��(40bits(+24bits))
				if (i + 5 > m_dwDataSize)
					break;
				m_Header.Extention.Display.byVideoFormat = (m_pData[i + 0] & 0x0EU) >> 1;
				m_Header.Extention.Display.bColorDescrption = (m_pData[i + 0] & 0x01U) != 0;
				if (m_Header.Extention.Display.bColorDescrption) {
					if (i + 5 + 3 > m_dwDataSize)
						break;
					m_Header.Extention.Display.Color.byColorPrimaries = m_pData[i + 1];
					m_Header.Extention.Display.Color.byTransferCharacteristics = m_pData[i + 2];
					m_Header.Extention.Display.Color.byMatrixCoefficients = m_pData[i + 3];
					i += 3;
				}
				if ((m_pData[i + 2] & 0x02) == 0)	// marker bit
					break;
				if ((m_pData[i + 4] & 0x07) != 0)	// marker bit
					break;
				m_Header.Extention.Display.wDisplayHorizontalSize = ((WORD)m_pData[i + 1] << 6) | ((WORD)(m_pData[i + 2] & 0xFCU) >> 2);
				m_Header.Extention.Display.wDisplayVerticalSize   = ((WORD)(m_pData[i + 2] & 0x01U) << 13) | ((WORD)m_pData[i + 3] << 5) | ((WORD)(m_pData[i + 4] & 0xF8U) >> 3);
				// For CyberLink decoder bug.
				if (m_bFixSquareDisplay
						&& m_Header.Extention.Display.wDisplayHorizontalSize == 1080
						&& m_Header.Extention.Display.wDisplayVerticalSize == 1080
						&& m_Header.byAspectRatioInfo == 2) {
					m_pData[i + 1] = m_Header.wHorizontalSize >> 6;
					m_pData[i + 2] = ((m_Header.wHorizontalSize & 0x3F) << 2) | (m_pData[i + 2] & 0x03);
					*pAspectRatioInfo = (3 << 4) | (*pAspectRatioInfo & 0x0F);
				}
				m_Header.Extention.Display.bHave = true;
				i += 5;
				break;
			}
		}
	}

	return true;
}

void CMpeg2Sequence::Reset(void)
{
	// �f�[�^���N���A����
	ClearSize();
	::ZeroMemory(&m_Header, sizeof(m_Header));
}

const WORD CMpeg2Sequence::GetHorizontalSize(void) const
{
	// Horizontal Size Value ��Ԃ�
	return m_Header.wHorizontalSize;
}

const WORD CMpeg2Sequence::GetVerticalSize(void) const
{
	// Vertical Size Value ��Ԃ�
	return m_Header.wVerticalSize;
}

const BYTE CMpeg2Sequence::GetAspectRatioInfo(void) const
{
	// Aspect Ratio Information ��Ԃ�
	return m_Header.byAspectRatioInfo;
}

const bool CMpeg2Sequence::GetAspectRatio(BYTE *pAspectX, BYTE *pAspectY) const
{
	BYTE AspectX, AspectY;

	switch (m_Header.byAspectRatioInfo) {
	case 1:
		AspectX = 1;
		AspectY = 1;
		break;
	case 2:
		AspectX = 4;
		AspectY = 3;
		break;
	case 3:
		AspectX = 16;
		AspectY = 9;
		break;
	case 4:
		AspectX = 221;
		AspectY = 100;
		break;
	default:
		return false;
	}
	if (pAspectX)
		*pAspectX = AspectX;
	if (pAspectY)
		*pAspectY = AspectY;
	return true;
}

const BYTE CMpeg2Sequence::GetFrameRateCode(void) const
{
	// Frame Rate Code ��Ԃ�
	return m_Header.byFrameRateCode;
}

const bool CMpeg2Sequence::GetFrameRate(DWORD *pNum, DWORD *pDenom) const
{
	static const struct {
		WORD Num, Denom;
	} FrameRateList[] = {
		{24000, 1001},	// 23.976
		{   24,    1},	// 24
		{   25,    1},	// 25
		{30000, 1001},	// 29.97
		{   30,    1},	// 30
		{   50,    1},	// 50
		{60000, 1001},	// 59.94
		{   60,    1},	// 60
	};

	if (m_Header.byFrameRateCode == 0 || m_Header.byFrameRateCode > 8)
		return false;
	if (pNum)
		*pNum = FrameRateList[m_Header.byFrameRateCode - 1].Num;
	if (pDenom)
		*pDenom = FrameRateList[m_Header.byFrameRateCode - 1].Denom;
	return true;
}

const DWORD CMpeg2Sequence::GetBitRate(void) const
{
	// Bit Rate Value ��Ԃ�
	return m_Header.dwBitRate;
}

const bool CMpeg2Sequence::IsMarkerBit(void) const
{
	// Marker Bit ��Ԃ�
	return m_Header.bMarkerBit;
}

const DWORD CMpeg2Sequence::GetVbvBufferSize(void) const
{
	// VBV Buffer Size Value ��Ԃ�
	return m_Header.dwVbvBufferSize;
}

const bool CMpeg2Sequence::IsConstrainedParamFlag(void) const
{
	// Constrained Parameters Flag ��Ԃ�
	return m_Header.bConstrainedParamFlag;
}

const bool CMpeg2Sequence::IsLoadIntraQuantiserMatrix(void) const
{
	// Load Intra Quantiser Matrix ��Ԃ�
	return m_Header.bLoadIntraQuantiserMatrix;
}

const bool CMpeg2Sequence::GetExtendDisplayInfo() const
{
	// Extention Sequence Display �����邩��Ԃ�
	return m_Header.Extention.Display.bHave;
}

const WORD CMpeg2Sequence::GetExtendDisplayHorizontalSize(void) const
{
	// Horizontal Size Value ��Ԃ�
	return m_Header.Extention.Display.wDisplayHorizontalSize;
}

const WORD CMpeg2Sequence::GetExtendDisplayVerticalSize(void) const
{
	// Vertical Size Value ��Ԃ�
	return m_Header.Extention.Display.wDisplayVerticalSize;
}

void CMpeg2Sequence::SetFixSquareDisplay(bool bFix)
{
	m_bFixSquareDisplay = bFix;
}


//////////////////////////////////////////////////////////////////////
// CMpeg2Parser�N���X�̍\�z/����
//////////////////////////////////////////////////////////////////////

CMpeg2Parser::CMpeg2Parser(ISequenceHandler *pSequenceHandler)
	: m_pSequenceHandler(pSequenceHandler)
{
	Reset();
}

CMpeg2Parser::CMpeg2Parser(const CMpeg2Parser &Operand)
{
	*this = Operand;
}

CMpeg2Parser & CMpeg2Parser::operator = (const CMpeg2Parser &Operand)
{
	// �C���X�^���X�̃R�s�[
	if (&Operand != this) {
		m_pSequenceHandler = Operand.m_pSequenceHandler;
		m_Mpeg2Sequence = Operand.m_Mpeg2Sequence;
		//m_bIsStoring = Operand.m_bIsStoring;
		m_dwSyncState = Operand.m_dwSyncState;
	}

	return *this;
}

const bool CMpeg2Parser::StorePacket(const CPesPacket *pPacket)
{
	return StoreEs(pPacket->GetPayloadData(), pPacket->GetPayloadSize());
}

const bool CMpeg2Parser::StoreEs(const BYTE *pData, const DWORD dwSize)
{
	static const BYTE StartCode[] = {0x00U, 0x00U, 0x01U, 0xB3U};
	bool bTrigger = false;
	DWORD dwPos,dwStart;

	for (dwPos = 0UL; dwPos < dwSize; dwPos += dwStart) {
		// �X�^�[�g�R�[�h����������
		//dwStart = FindStartCode(&pData[dwPos], dwSize - dwPos);
		DWORD Remain = dwSize - dwPos;
		DWORD SyncState = m_dwSyncState;
		for (dwStart = 0UL; dwStart < Remain; dwStart++) {
			SyncState=(SyncState<<8) | (DWORD)pData[dwPos + dwStart];
			if (SyncState == 0x000001B3UL) {
				// �X�^�[�g�R�[�h�����A�V�t�g���W�X�^������������
				SyncState = 0xFFFFFFFFUL;
				break;
			}
		}
		m_dwSyncState = SyncState;

		if (dwStart < Remain) {
			dwStart++;
			if (m_Mpeg2Sequence.GetSize() >= 4UL) {
				if (dwStart < 4UL) {
					// �X�^�[�g�R�[�h�̒f�Ђ���菜��
					m_Mpeg2Sequence.TrimTail(4UL - dwStart);
				} else if (dwStart > 4UL) {
					m_Mpeg2Sequence.AddData(&pData[dwPos], dwStart - 4);
				}

				// �V�[�P���X���o�͂���
				if (m_Mpeg2Sequence.ParseHeader())
					OnMpeg2Sequence(&m_Mpeg2Sequence);
			}

			// �X�^�[�g�R�[�h���Z�b�g����
			m_Mpeg2Sequence.SetData(StartCode, 4UL);
			bTrigger = true;
		} else {
			if (m_Mpeg2Sequence.GetSize() >= 4UL) {
				// �V�[�P���X�X�g�A
				if (m_Mpeg2Sequence.AddData(&pData[dwPos], Remain) >= 0x1000000UL) {
					// ��O(�V�[�P���X��16MB�𒴂���)
					m_Mpeg2Sequence.ClearSize();
				}
			}
			break;
		}
	}

	return bTrigger;
}

void CMpeg2Parser::Reset(void)
{
	// ��Ԃ�����������
	//m_bIsStoring = false;
	m_dwSyncState = 0xFFFFFFFFUL;

	m_Mpeg2Sequence.Reset();
}

void CMpeg2Parser::SetFixSquareDisplay(bool bFix)
{
	m_Mpeg2Sequence.SetFixSquareDisplay(bFix);
}

void CMpeg2Parser::OnPesPacket(const CPesParser *pPesParser, const CPesPacket *pPacket)
{
	// CPesParser::IPacketHandler�C���^�t�F�[�X�̎���
	StorePacket(pPacket);
}

void CMpeg2Parser::OnMpeg2Sequence(const CMpeg2Sequence *pSequence) const
{
	// �n���h���Ăяo��
	if(m_pSequenceHandler)m_pSequenceHandler->OnMpeg2Sequence(this, pSequence);
}

/*
inline const DWORD CMpeg2Parser::FindStartCode(const BYTE *pData, const DWORD dwDataSize)
{
	// Sequence Header Code (0x000001B3) ����������
	DWORD dwPos;

	for(dwPos = 0UL ; dwPos < dwDataSize ; dwPos++){
		m_dwSyncState <<= 8;
		m_dwSyncState |= (DWORD)pData[dwPos];

		if(m_dwSyncState == 0x000001B3UL){
			// �X�^�[�g�R�[�h�����A�V�t�g���W�X�^������������
			m_dwSyncState = 0xFFFFFFFFUL;
			break;
			}
		}

	return dwPos;
}
*/




//////////////////////////////////////////////////////////////////////
// CH264AccessUnit�N���X�̍\�z/����
//////////////////////////////////////////////////////////////////////

#include "Bitstream.h"

//#define STRICT_1SEG	// �����Z�O�K�i����

CH264AccessUnit::CH264AccessUnit()
{
	Reset();
}

CH264AccessUnit::CH264AccessUnit(const CH264AccessUnit &Operand)
{
	*this = Operand;
}

CH264AccessUnit & CH264AccessUnit::operator = (const CH264AccessUnit &Operand)
{
	if (this != &Operand) {
		m_Header = Operand.m_Header;
	}
	return *this;
}

static DWORD EBSPToRBSP(BYTE *pData, DWORD DataSize)
{
	DWORD j = 0;
	int Count = 0;
	for (DWORD i = 0; i < DataSize; i++) {
		if (Count == 2) {
			if (pData[i] < 0x03)
				return (DWORD)-1;
			if (pData[i] == 0x03) {
				if (i < DataSize - 1 && pData[i + 1] > 0x03)
					return (DWORD)-1;
				if (i == DataSize - 1)
					break;
				i++;
				Count = 0;
			}
		}
		pData[j++] = pData[i];
		if (pData[i] == 0x00)
			Count++;
		else
			Count = 0;
	}
	return j;
}

const bool CH264AccessUnit::ParseHeader(void)
{
	if (m_dwDataSize < 5
			|| m_pData[0] != 0 || m_pData[1] != 0 || m_pData[2] != 0x01)
		return false;

	DWORD Pos = 3;
	while (true) {
		DWORD SyncState = 0xFFFFFFFFUL;
		DWORD NextPos = Pos + 1;
		bool bFoundStartCode = false;
		for (; NextPos < m_dwDataSize - 2; NextPos++) {
			SyncState = (SyncState << 8) | (DWORD)m_pData[NextPos];
			if ((SyncState & 0x00FFFFFF) == 0x00000001UL) {
				bFoundStartCode = true;
				NextPos++;
				break;
			}
		}
		if (!bFoundStartCode)
			break;

		const BYTE NALUnitType = m_pData[Pos++] & 0x1F;
		DWORD NALUnitSize = NextPos - 3 - Pos;

		NALUnitSize = EBSPToRBSP(&m_pData[Pos], NALUnitSize);
		if (NALUnitSize == (DWORD)-1)
			break;

		if (NALUnitType == 0x07) {
			// Sequence parameter set
			CBitstream Bitstream(&m_pData[Pos], NALUnitSize);

			m_Header.SPS.ProfileIdc = (BYTE)Bitstream.GetBits(8);
			m_Header.SPS.bConstraintSet0Flag = Bitstream.GetFlag();
			m_Header.SPS.bConstraintSet1Flag = Bitstream.GetFlag();
			m_Header.SPS.bConstraintSet2Flag = Bitstream.GetFlag();
			m_Header.SPS.bConstraintSet3Flag = Bitstream.GetFlag();
			if (Bitstream.GetBits(4) != 0)	// reserved_zero_4bits
				return false;
			m_Header.SPS.LevelIdc = (BYTE)Bitstream.GetBits(8);
			m_Header.SPS.SeqParameterSetId = Bitstream.GetUE_V();
			m_Header.SPS.ChromaFormatIdc = 1;
			m_Header.SPS.bSeparateColourPlaneFlag = false;
			m_Header.SPS.BitDepthLumaMinus8 = 0;
			m_Header.SPS.BitDepthChromaMinus8 = 0;
			m_Header.SPS.bQpprimeYZeroTransformBypassFlag = false;
			m_Header.SPS.bSeqScalingMatrixPresentFlag = false;
			if (m_Header.SPS.ProfileIdc == 100
					|| m_Header.SPS.ProfileIdc == 110
					|| m_Header.SPS.ProfileIdc == 122
					|| m_Header.SPS.ProfileIdc == 244
					|| m_Header.SPS.ProfileIdc == 44
					|| m_Header.SPS.ProfileIdc == 83
					|| m_Header.SPS.ProfileIdc == 86) {
				// High profile
				m_Header.SPS.ChromaFormatIdc = Bitstream.GetUE_V();
				if (m_Header.SPS.ChromaFormatIdc == 3)	// YUY444
					m_Header.SPS.bSeparateColourPlaneFlag = Bitstream.GetFlag();
				m_Header.SPS.BitDepthLumaMinus8 = Bitstream.GetUE_V();
				m_Header.SPS.BitDepthChromaMinus8 = Bitstream.GetUE_V();
				m_Header.SPS.bQpprimeYZeroTransformBypassFlag = Bitstream.GetFlag();
				m_Header.SPS.bSeqScalingMatrixPresentFlag = Bitstream.GetFlag();
				if (m_Header.SPS.bSeqScalingMatrixPresentFlag) {
					const int Length = m_Header.SPS.ChromaFormatIdc != 3 ? 8 : 12;
					for (int i = 0; i < Length; i++) {
						if (Bitstream.GetFlag()) {	// seq_scaling_list_present_flag
							int LastScale = 8, NextScale = 8;
							for (int j = 0; j < (i < 6 ? 16 : 64); j++) {
								if (NextScale != 0) {
									int DeltaScale = Bitstream.GetSE_V();
									NextScale = (LastScale + DeltaScale + 256) % 256;
									LastScale = NextScale;
								}
							}
						}
					}
				}
			}
			m_Header.SPS.Log2MaxFrameNumMinus4 = Bitstream.GetUE_V();
			m_Header.SPS.PicOrderCntType = Bitstream.GetUE_V();
			if (m_Header.SPS.PicOrderCntType == 0) {
				m_Header.SPS.Log2MaxPicOrderCntLsbMinus4 = Bitstream.GetUE_V();
			} else if (m_Header.SPS.PicOrderCntType == 1) {
				m_Header.SPS.bDeltaPicOrderAlwaysZeroFlag = Bitstream.GetFlag();
				m_Header.SPS.OffsetForNonRefPic = Bitstream.GetSE_V();
				m_Header.SPS.OffsetForTopToBottomField = Bitstream.GetSE_V();
				m_Header.SPS.NumRefFramesInPicOrderCntCycle = Bitstream.GetUE_V();
				for (int i = 0; i < m_Header.SPS.NumRefFramesInPicOrderCntCycle; i++)
					Bitstream.GetSE_V();	// offset_for_ref_frame
			}
			m_Header.SPS.NumRefFrames = Bitstream.GetUE_V();
			m_Header.SPS.bGapsInFrameNumValueAllowedFlag = Bitstream.GetFlag();
			m_Header.SPS.PicWidthInMbsMinus1 = Bitstream.GetUE_V();
			m_Header.SPS.PicHeightInMapUnitsMinus1 = Bitstream.GetUE_V();
			m_Header.SPS.bFrameMbsOnlyFlag = Bitstream.GetFlag();
			if (!m_Header.SPS.bFrameMbsOnlyFlag)
				m_Header.SPS.bMbAdaptiveFrameFieldFlag = Bitstream.GetFlag();
			m_Header.SPS.bDirect8x8InferenceFlag = Bitstream.GetFlag();
			m_Header.SPS.bFrameCroppingFlag = Bitstream.GetFlag();
			if (m_Header.SPS.bFrameCroppingFlag) {
				m_Header.SPS.FrameCropLeftOffset = Bitstream.GetUE_V();
				m_Header.SPS.FrameCropRightOffset = Bitstream.GetUE_V();
				m_Header.SPS.FrameCropTopOffset = Bitstream.GetUE_V();
				m_Header.SPS.FrameCropBottomOffset = Bitstream.GetUE_V();
			}
			m_Header.SPS.bVuiParametersPresentFlag = Bitstream.GetFlag();
			if (m_Header.SPS.bVuiParametersPresentFlag) {
				m_Header.SPS.VUI.bAspectRatioInfoPresentFlag = Bitstream.GetFlag();
				if (m_Header.SPS.VUI.bAspectRatioInfoPresentFlag) {
					m_Header.SPS.VUI.AspectRatioIdc = (BYTE)Bitstream.GetBits(8);
					if (m_Header.SPS.VUI.AspectRatioIdc == 255) {
						m_Header.SPS.VUI.SarWidth = (WORD)Bitstream.GetBits(16);
						m_Header.SPS.VUI.SarHeight = (WORD)Bitstream.GetBits(16);
					}
				}
				m_Header.SPS.VUI.bOverscanInfoPresentFlag = Bitstream.GetFlag();
				if (m_Header.SPS.VUI.bOverscanInfoPresentFlag)
					m_Header.SPS.VUI.bOverscanAppropriateFlag = Bitstream.GetFlag();
				m_Header.SPS.VUI.bVideoSignalTypePresentFlag = Bitstream.GetFlag();
				if (m_Header.SPS.VUI.bVideoSignalTypePresentFlag) {
					m_Header.SPS.VUI.VideoFormat = (BYTE)Bitstream.GetBits(3);
					m_Header.SPS.VUI.bVideoFullRangeFlag = Bitstream.GetFlag();
					m_Header.SPS.VUI.bColourDescriptionPresentFlag = Bitstream.GetFlag();
					if (m_Header.SPS.VUI.bColourDescriptionPresentFlag) {
						m_Header.SPS.VUI.ColourPrimaries = (BYTE)Bitstream.GetBits(8);
						m_Header.SPS.VUI.TransferCharacteristics = (BYTE)Bitstream.GetBits(8);
						m_Header.SPS.VUI.MatrixCoefficients = (BYTE)Bitstream.GetBits(8);
					}
				}
				m_Header.SPS.VUI.bChromaLocInfoPresentFlag = Bitstream.GetFlag();
				if (m_Header.SPS.VUI.bChromaLocInfoPresentFlag) {
					m_Header.SPS.VUI.ChromaSampleLocTypeTopField = Bitstream.GetUE_V();
					m_Header.SPS.VUI.ChromaSampleLocTypeBottomField = Bitstream.GetUE_V();
				}
				m_Header.SPS.VUI.bTimingInfoPresentFlag = Bitstream.GetFlag();
				if (m_Header.SPS.VUI.bTimingInfoPresentFlag) {
					m_Header.SPS.VUI.NumUnitsInTick = Bitstream.GetBits(32);
					m_Header.SPS.VUI.TimeScale = Bitstream.GetBits(32);
					m_Header.SPS.VUI.bFixedFrameRateFlag = Bitstream.GetFlag();
				}
				// �ȉ��܂��܂����邪�ȗ�
			}
			if (m_Header.SPS.bSeparateColourPlaneFlag)
				m_Header.SPS.ChromaArrayType = m_Header.SPS.ChromaFormatIdc;
			else
				m_Header.SPS.ChromaArrayType = 0;
#ifdef STRICT_1SEG
			// �����Z�O�K�i�ɍ��v���Ă���?
			if (m_Header.SPS.ProfileIdc != 66
					|| !m_Header.SPS.bConstraintSet0Flag
					|| !m_Header.SPS.bConstraintSet1Flag
					|| !m_Header.SPS.bConstraintSet2Flag
					|| m_Header.SPS.LevelIdc != 12
					|| m_Header.SPS.SeqParameterSetID > 31
					|| m_Header.SPS.Log2MaxFrameNumMinus4 > 12
					|| m_Header.SPS.PicOrderCntType != 2
					|| m_Header.SPS.NumRefFrames == 0
						|| m_Header.SPS.NumRefFrames > 3
					|| m_Header.SPS.bGapsInFrameNumValueAllowedFlag
					|| m_Header.SPS.PicWidthInMbsMinus1 != 19
					|| (m_Header.SPS.PicHeightInMapUnitsMinus1 != 11
						&& m_Header.SPS.PicHeightInMapUnitsMinus1 != 14)
					|| !m_Header.SPS.bFrameMbsOnlyFlag
					|| !m_Header.SPS.bDirect8x8InferenceFlag
					|| (m_Header.SPS.bFrameCroppingFlag !=
						(m_Header.SPS.PicHeightInMapUnitsMinus1 == 11))
					|| (m_Header.SPS.bFrameCroppingFlag
						&& (m_Header.SPS.FrameCropLeftOffset != 0
							|| m_Header.SPS.FrameCropRightOffset != 0
							|| m_Header.SPS.FrameCropTopOffset != 0
							|| m_Header.SPS.FrameCropBottomOffset != 6))
					|| !m_Header.SPS.bVuiParametersPresentFlag
					|| m_Header.SPS.VUI.bAspectRatioInfoPresentFlag
					|| m_Header.SPS.VUI.bOverscanInfoPresentFlag
					|| m_Header.SPS.VUI.bVideoSignalTypePresentFlag
					|| m_Header.SPS.VUI.bChromaLocInfoPresentFlag
					|| !m_Header.SPS.VUI.bTimingInfoPresentFlag
					|| m_Header.SPS.VUI.NumUnitsInTick == 0
					|| m_Header.SPS.VUI.NumUnitsInTick % 1001 != 0
					|| (m_Header.SPS.VUI.TimeScale != 24000
						&& m_Header.SPS.VUI.TimeScale != 30000)) {
				return false;
			}
#endif
			m_bFoundSPS = true;
		} else if (NALUnitType == 0x09) {
			// Access unit delimiter
			m_Header.AUD.PrimaryPicType = m_pData[Pos] >> 5;
		} else if (NALUnitType == 0x0A) {
			// End of sequence
			break;
		}

		Pos = NextPos;
	}

	return m_bFoundSPS;
}

void CH264AccessUnit::Reset(void)
{
	m_bFoundSPS = false;
	::ZeroMemory(&m_Header, sizeof(TAG_H264ACCESSUNIT));
}

const WORD CH264AccessUnit::GetHorizontalSize() const
{
	WORD Width = (m_Header.SPS.PicWidthInMbsMinus1 + 1) * 16;
	WORD Crop = m_Header.SPS.bFrameCroppingFlag ?
		m_Header.SPS.FrameCropLeftOffset + m_Header.SPS.FrameCropRightOffset : 0;
	/*
	if (m_Header.SPS.ChromaArrayType != 0)
		Crop *= SubWidthC;
	*/
	return Width - Crop;
}

const WORD CH264AccessUnit::GetVerticalSize() const
{
	WORD Height = (m_Header.SPS.PicHeightInMapUnitsMinus1 + 1) * 16;
	WORD Crop = m_Header.SPS.bFrameCroppingFlag ?
		m_Header.SPS.FrameCropTopOffset + m_Header.SPS.FrameCropBottomOffset : 0;
	if (!m_Header.SPS.bFrameMbsOnlyFlag)
		Height *= 2;
	/*
	if (m_Header.SPS.ChromaArrayType != 0)
		 Crop *= SubHeightC;
	*/
	if (m_Header.SPS.bFrameMbsOnlyFlag)
		Crop *= 2;
	else
		Crop *= 4;
	return Height - Crop;
}

const bool CH264AccessUnit::GetSAR(WORD *pHorz, WORD *pVert) const
{
	static const struct {
		BYTE Horz, Vert;
	} SarList[] = {
		{  0,   0},
		{  1,   1},
		{ 12,  11},
		{ 10,  11},
		{ 16,  11},
		{ 40,  33},
		{ 24,  11},
		{ 20,  11},
		{ 32,  11},
		{ 80,  33},
		{ 18,  11},
		{ 15,  11},
		{ 64,  33},
		{160,  99},
		{  4,   3},
		{  3,   2},
		{  2,   1},
	};

	if (!m_Header.SPS.bVuiParametersPresentFlag
			|| !m_Header.SPS.VUI.bAspectRatioInfoPresentFlag)
		return false;

	WORD Horz, Vert;
	if (m_Header.SPS.VUI.AspectRatioIdc <= 16) {
		Horz = SarList[m_Header.SPS.VUI.AspectRatioIdc].Horz;
		Vert = SarList[m_Header.SPS.VUI.AspectRatioIdc].Vert;
	} else if (m_Header.SPS.VUI.AspectRatioIdc == 255) {	// Extended_SAR
		Horz = m_Header.SPS.VUI.SarWidth;
		Vert = m_Header.SPS.VUI.SarHeight;
	} else {
		return false;
	}
	if (pHorz)
		*pHorz = Horz;
	if (pVert)
		*pVert = Vert;
	return true;
}

const bool CH264AccessUnit::GetTimingInfo(TimingInfo *pInfo) const
{
	if (!m_Header.SPS.bVuiParametersPresentFlag
			|| !m_Header.SPS.VUI.bTimingInfoPresentFlag)
		return false;
	if (pInfo) {
		pInfo->NumUnitsInTick = m_Header.SPS.VUI.NumUnitsInTick;
		pInfo->TimeScale = m_Header.SPS.VUI.TimeScale;
		pInfo->bFixedFrameRateFlag = m_Header.SPS.VUI.bFixedFrameRateFlag;
	}
	return true;
}




//////////////////////////////////////////////////////////////////////
// CH264Parser�N���X�̍\�z/����
//////////////////////////////////////////////////////////////////////


CH264Parser::CH264Parser(IAccessUnitHandler *pAccessUnitHandler)
	: m_pAccessUnitHandler(pAccessUnitHandler)
{
	Reset();
}

CH264Parser::CH264Parser(const CH264Parser &Operand)
{
	*this = Operand;
}

CH264Parser & CH264Parser::operator = (const CH264Parser &Operand)
{
	// �C���X�^���X�̃R�s�[
	if (&Operand != this) {
		m_pAccessUnitHandler = Operand.m_pAccessUnitHandler;
		m_AccessUnit = Operand.m_AccessUnit;
		m_dwSyncState = Operand.m_dwSyncState;
	}

	return *this;
}

const bool CH264Parser::StorePacket(const CPesPacket *pPacket)
{
	return StoreEs(pPacket->GetPayloadData(), pPacket->GetPayloadSize());
}

const bool CH264Parser::StoreEs(const BYTE *pData, const DWORD dwSize)
{
	bool bTrigger = false;
	DWORD dwPos,dwStart;

	for (dwPos = 0UL ; dwPos < dwSize ; dwPos += dwStart) {
		// Access unit delimiter����������
		DWORD Remain = dwSize - dwPos;
		DWORD SyncState = m_dwSyncState;
		for (dwStart = 0UL ; dwStart < Remain ; dwStart++) {
			SyncState = (SyncState << 8) | (DWORD)pData[dwStart + dwPos];
			if ((SyncState & 0xFFFFFF1F) == 0x00000109UL) {
				// Access unit delimiter����
				break;
			}
		}

		if (dwStart < Remain) {
			dwStart++;
			if (m_AccessUnit.GetSize() >= 4) {
				if (dwStart > 4) {
					m_AccessUnit.AddData(&pData[dwPos], dwStart - 4);
				} else if (dwStart < 4) {
					// �X�^�[�g�R�[�h�̒f�Ђ���菜��
					m_AccessUnit.TrimTail(4 - dwStart);
				}

				// �V�[�P���X���o�͂���
				if (m_AccessUnit.ParseHeader())
					OnAccessUnit(&m_AccessUnit);
			}

			// �X�^�[�g�R�[�h���Z�b�g����
			BYTE StartCode[4];
			StartCode[0] = (BYTE)(SyncState >> 24);
			StartCode[1] = (BYTE)((SyncState >> 16) & 0xFF);
			StartCode[2] = (BYTE)((SyncState >> 8) & 0xFF);
			StartCode[3] = (BYTE)(SyncState & 0xFF);
			m_AccessUnit.SetData(StartCode, 4);

			// �V�t�g���W�X�^������������
			m_dwSyncState = 0xFFFFFFFFUL;
			bTrigger = true;
		} else if (m_AccessUnit.GetSize() >= 4) {
			// �V�[�P���X�X�g�A
			if (m_AccessUnit.AddData(&pData[dwPos], Remain) >= 0x1000000UL) {
				// ��O(�V�[�P���X��16MB�𒴂���)
				m_AccessUnit.ClearSize();
			}
		}
	}

	return bTrigger;
}

void CH264Parser::Reset(void)
{
	// ��Ԃ�����������
	m_dwSyncState = 0xFFFFFFFFUL;

	m_AccessUnit.Reset();
}

void CH264Parser::OnPesPacket(const CPesParser *pPesParser, const CPesPacket *pPacket)
{
	// CPesParser::IPacketHandler�C���^�t�F�[�X�̎���
	StorePacket(pPacket);
}

void CH264Parser::OnAccessUnit(const CH264AccessUnit *pAccessUnit) const
{
	// �n���h���Ăяo��
	if (m_pAccessUnitHandler)
		m_pAccessUnitHandler->OnAccessUnit(this, pAccessUnit);
}
