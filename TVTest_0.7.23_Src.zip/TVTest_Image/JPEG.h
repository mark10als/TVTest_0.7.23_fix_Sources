#ifndef TVTEST_JPEG_H
#define TVTEST_JPGE_H


bool SaveJPEGFile(const ImageSaveInfo *pInfo);


#endif
