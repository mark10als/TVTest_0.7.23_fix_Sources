#ifndef TVTEST_BMP_H
#define TVTEST_BMP_H


bool SaveBMPFile(const ImageSaveInfo *pInfo);


#endif
