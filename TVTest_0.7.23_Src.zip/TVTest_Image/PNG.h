#ifndef TVTEST_PNG_H
#define TVTEST_PNE_H


bool SavePNGFile(const ImageSaveInfo *pInfo);
HGLOBAL LoadAribPng(const void *pData,SIZE_T DataSize);


#endif
